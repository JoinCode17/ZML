killall Tiny
iptables -t mangle -P OUTPUT ACCEPT
iptables -t mangle -F OUTPUT
iptables -t mangle -P FORWARD ACCEPT
iptables -t mangle -F FORWARD
iptables -t nat -F OUTPUT
iptables -t nat -F PREROUTING
svc data disable
echo " ● 已关闭防跳 "
echo " ● 已关闭网络"
