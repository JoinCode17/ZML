#内网IP白名单,输入前两段IP例如10.35
IP=""

#DNS,留空通过tiny转发
DNS=""

#禁网
UID1="1000"

#放行非TCP协议
UID2=""

#放行所有协议
UID3=""

#共享放行其它协议，填任意字符放行
GX=""

#共享udp协议,填on放行
HJ="on"

#自动识别并放行王者荣耀，穿越火线，球球大作战，火影，王者荣耀体验版，虎牙直播UID并放行相关udp协议，填on放行
YX="on"

#网络重启防止跳流量，填on开启
CQ="on"

#直接玩LOL，填on开启
LOL="on"

#################################################
cd "${0%/*}"
./Stop.sh
./Tiny -c ./Tiny.conf
. ./Tiny.conf
udp1=`grep com.tencent.tmgp.sgame /data/system/packages.list  | cut -d " " -f 2`
udp2=`grep com.tencent.tmgp.cf /data/system/packages.list  | cut -d " " -f 2`
udp3=`grep com.ztgame.bob /data/system/packages.list  | cut -d " " -f 2`
udp4=`grep com.netease.onmyoji /data/system/packages.list  | cut -d " " -f 2`
udp5=`grep com.netease.my /data/system/packages.list  | cut -d " " -f 2`
udp6=`grep com.duowan.kiwi /data/system/packages.list  | cut -d " " -f 2`
if [[ $YX == "on" ]]
then
for YX in $udp1 $udp2 $udp3 $udp4 $udp5 $udp6;do
iptables -t nat -I OUTPUT -p udp -m owner --uid-owner $YX -j ACCEPT;done
iptables -t mangle -I OUTPUT -p tcp -m tcp --tcp-flags FIN,SYN,RST SYN -m state --state NEW -j ACCEPT
iptables -t mangle -I OUTPUT -p tcp -m state --state ESTABLISHED -j ACCEPT
iptables -t mangle -I OUTPUT -p udp -m state --state NEW,ESTABLISHED -j ACCEPT
echo " ● 放行游戏UID $udp1 $udp2 $udp3 $udp4 $udp5 $udp6 "
else
iptables -t mangle -P OUTPUT ACCEPT
iptables -t mangle -F OUTPUT
iptables -t mangle -P FORWARD ACCEPT
iptables -t mangle -F FORWARD
iptables -t nat -F OUTPUT
iptables -t nat -F PREROUTING;fi
iptables -t mangle -P OUTPUT DROP
if [[ $IP != "" ]]
then
for J in $IP
do
iptables -t mangle -I OUTPUT -p tcp -s $J/16 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
iptables -t mangle -I OUTPUT -p udp -s $J/16 --dport 53 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT;done
else
iptables -t mangle -I OUTPUT -p tcp -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
iptables -t mangle -I OUTPUT -p udp --dport 53 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT;fi
iptables -t mangle -I OUTPUT -o wlan+ -j ACCEPT
iptables -t mangle -I OUTPUT -o tun+ -j ACCEPT
iptables -t mangle -I OUTPUT -o ap+ -j ACCEPT
iptables -t mangle -I OUTPUT -o lo -j ACCEPT
if [[ $DNS != "" ]]
then
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-des $DNS
else
iptables -t nat -I OUTPUT -p udp --dport 53 -j REDIRECT --to $dns_listen_port;fi
iptables -t nat -I OUTPUT -p tcp -m owner ! --uid-owner $user$uid -j REDIRECT --to $listen_port
iptables -t nat -I OUTPUT -o wlan+ -j ACCEPT
iptables -t nat -I OUTPUT -o tun+ -j ACCEPT
iptables -t nat -I OUTPUT -o ap+ -j ACCEPT
iptables -t nat -I OUTPUT -o lo -j ACCEPT
iptables -t mangle -P FORWARD DROP
iptables -t nat -I PREROUTING -s 192.168/16 -p tcp ! -d 192.168/16 -j REDIRECT --to $listen_port
if [[ $UID1 != "" ]]
then
for J in $UID1
do
iptables -t mangle -I OUTPUT -m owner --uid-owner $J -j DROP;done;fi
if [[ $UID2 != "" ]]
then
for J in $UID2;do
iptables -t mangle -I OUTPUT -m owner --uid-owner $J -j ACCEPT;done;fi
if [[ $UID3 != "" ]]
then
for J in $UID3
do
iptables -t mangle -I OUTPUT -m owner --uid-owner $J -j ACCEPT
iptables -t nat -I OUTPUT -m owner --uid-owner $J -j ACCEPT;done;fi
if [[ $GX != "" ]]
then
iptables -t mangle -P FORWARD ACCEPT;fi
if [[ $HJ == "on" ]]
then
iptables -t nat -I PREROUTING -s 192.168/16 -p udp -j ACCEPT
for G in  PREROUTING FORWARD;do
iptables -t mangle -I $G -s 192.168/16 -p udp -j ACCEPT;done
echo " ● 已放行共享UDP协议"
fi
if [[ $LOL == "on" ]]
then
iptables -t mangle -A FORWARD -p udp -j ACCEPT
iptables -t mangle -I OUTPUT -s 192.168/16 -j ACCEPT
echo " ● 已可以直接LOL"
fi
if [[ $CQ == "on" ]]
then
svc data disable
svc data enable
echo " ● 已重启网络"
fi
rm *.bak
./State.sh
