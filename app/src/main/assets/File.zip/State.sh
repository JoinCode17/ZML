echo "  "
for u in Tiny
do
if [[ `ps|grep -i $u` != "" ]]
then
echo " ● 已启用 $u"
else
echo " ○ 已停用 $u"
fi
echo ""
echo "--------    防跳    --------"
done
echo "→ nat ←"
iptables -t nat -S OUTPUT
echo ""
iptables -t nat -S PREROUTING
echo ""
echo "→ mangle ←"
iptables -t mangle -S OUTPUT
echo ""
iptables -t mangle -S FORWARD
